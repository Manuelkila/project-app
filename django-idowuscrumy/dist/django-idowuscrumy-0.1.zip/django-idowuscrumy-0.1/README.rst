This is a django app that says "welcome to django"
